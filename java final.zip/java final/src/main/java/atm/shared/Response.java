package atm.shared;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Response implements Serializable {
    private static final long serialVersionUID = 1L;

    public enum Status {
        SUCCESS,
        FAILURE,
        REQUIRE_OTP,
        LOCKED
    }

    private Status status;
    private String message;
    private Map<String, Object> payload;

    public Response(Status status, String message) {
        this.status = status;
        this.message = message;
        this.payload = new HashMap<>();
    }

    public Status getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public void setPayloadData(String key, Object value) {
        this.payload.put(key, value);
    }

    public Object getPayloadData(String key) {
        return this.payload.get(key);
    }
}
