package atm.shared;

import java.io.Serializable;
import java.math.BigDecimal;

public class User implements Serializable {
    private static final long serialVersionUID = 1L;

    private String accountNumber;
    private BigDecimal balance;
    private String mobile;
    private String email;

    public User(String accountNumber, BigDecimal balance, String mobile, String email) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.mobile = mobile;
        this.email = email;
    }

    public String getAccountNumber() { return accountNumber; }
    public BigDecimal getBalance() { return balance; }
    public String getMobile() { return mobile; }
    public String getEmail() { return email; }
}
