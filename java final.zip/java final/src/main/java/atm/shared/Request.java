package atm.shared;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Request implements Serializable {
    private static final long serialVersionUID = 1L;

    public enum RequestType {
        LOGIN,
        VERIFY_OTP,
        GET_BALANCE,
        DEPOSIT,
        WITHDRAW,
        MINI_STATEMENT,
        CHANGE_PASSWORD,
        LOGOUT
    }

    private RequestType type;
    private Map<String, Object> payload;

    public Request(RequestType type) {
        this.type = type;
        this.payload = new HashMap<>();
    }

    public RequestType getType() {
        return type;
    }

    public void setPayloadData(String key, Object value) {
        this.payload.put(key, value);
    }

    public Object getPayloadData(String key) {
        return this.payload.get(key);
    }
}
