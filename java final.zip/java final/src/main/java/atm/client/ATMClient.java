package atm.client;

import atm.shared.Request;
import atm.shared.Response;
import atm.shared.Transaction;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;
import java.util.List;

public class ATMClient extends JFrame {
    private NetworkManager networkManager;
    private CardLayout cardLayout;
    private JPanel mainPanel;
    private JPanel topPanel;
    private JComboBox<String> langCombo;

    // Panels
    private JPanel loginPanel;
    private JPanel otpPanel;
    private JPanel menuPanel;

    // Context
    private String currentAccount;

    // Languages
    private enum Language { ENGLISH, HINDI, ODIA }
    private Language currentLang = Language.ENGLISH;

    // UI Components to update
    private JLabel loginTitleLabel, loginAccLabel, loginPassLabel, otpTitleLabel, otpEnterLabel, menuTitleLabel;
    private JButton loginBtn, verifyBtn, balanceBtn, depositBtn, withdrawBtn, statementBtn, changePwdBtn, logoutBtn;

    // Styling constants
    private final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 28);
    private final Font LABEL_FONT = new Font("Segoe UI", Font.PLAIN, 16);
    private final Font BUTTON_FONT = new Font("Segoe UI", Font.BOLD, 16);
    private final Color PRIMARY_COLOR = new Color(58, 150, 221); // Dark theme blue
    private final Color SUCCESS_COLOR = new Color(35, 134, 54); // Dark theme green
    private final Color DANGER_COLOR = new Color(218, 54, 51); // Dark theme red
    private final Color BG_COLOR = new Color(30, 30, 30);
    private final Color PANEL_BG = new Color(45, 45, 45);
    private final Color TEXT_COLOR = new Color(230, 230, 230);

    public ATMClient() {
        // Apply System Look and Feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            UIManager.put("Panel.background", BG_COLOR);
            UIManager.put("OptionPane.background", BG_COLOR);
            UIManager.put("OptionPane.messageForeground", TEXT_COLOR);
            UIManager.put("TextField.background", PANEL_BG);
            UIManager.put("TextField.foreground", TEXT_COLOR);
            UIManager.put("TextField.caretForeground", TEXT_COLOR);
            UIManager.put("PasswordField.background", PANEL_BG);
            UIManager.put("PasswordField.foreground", TEXT_COLOR);
            UIManager.put("PasswordField.caretForeground", TEXT_COLOR);
            UIManager.put("Label.foreground", TEXT_COLOR);
            UIManager.put("ComboBox.background", PANEL_BG);
            UIManager.put("ComboBox.foreground", TEXT_COLOR);
            UIManager.put("Table.background", PANEL_BG);
            UIManager.put("Table.foreground", TEXT_COLOR);
            UIManager.put("ScrollPane.background", BG_COLOR);
            UIManager.put("TableHeader.background", PANEL_BG);
            UIManager.put("TableHeader.foreground", TEXT_COLOR);
        } catch (Exception e) {
            e.printStackTrace();
        }

        setTitle("Java ATM System");
        setSize(650, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(BG_COLOR);

        networkManager = new NetworkManager();
        try {
            networkManager.connect();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Could not connect to Server: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(BG_COLOR);

        initLoginPanel();
        initOTPPanel();
        initMenuPanel();
        add(mainPanel, BorderLayout.CENTER);

        updateUIText();
        cardLayout.show(mainPanel, "LOGIN");
    }

    private void initLoginPanel() {
        loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(PANEL_BG);
        loginPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
                new EmptyBorder(30, 40, 30, 40)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        loginTitleLabel = new JLabel("ATM Login", SwingConstants.CENTER);
        loginTitleLabel.setFont(TITLE_FONT);
        loginTitleLabel.setForeground(PRIMARY_COLOR);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        loginPanel.add(loginTitleLabel, gbc);

        gbc.gridwidth = 1; gbc.gridy = 1;
        loginAccLabel = new JLabel("Account Number:");
        loginAccLabel.setFont(LABEL_FONT);
        loginPanel.add(loginAccLabel, gbc);

        JTextField accField = new JTextField(15);
        accField.setFont(LABEL_FONT);
        gbc.gridx = 1;
        loginPanel.add(accField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        loginPassLabel = new JLabel("Password:");
        loginPassLabel.setFont(LABEL_FONT);
        loginPanel.add(loginPassLabel, gbc);

        JPasswordField passField = new JPasswordField(15);
        passField.setFont(LABEL_FONT);
        gbc.gridx = 1;
        loginPanel.add(passField, gbc);

        loginBtn = new JButton("Login");
        styleButton(loginBtn, PRIMARY_COLOR);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 10, 10, 10);
        loginPanel.add(loginBtn, gbc);

        loginBtn.addActionListener(e -> {
            String acc = accField.getText();
            String pass = new String(passField.getPassword());
            if (acc.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, getStr("msg_empty_fields"));
                return;
            }

            Request req = new Request(Request.RequestType.LOGIN);
            req.setPayloadData("accountNumber", acc);
            req.setPayloadData("password", pass);

            Response res = networkManager.sendRequest(req);
            if (res.getStatus() == Response.Status.REQUIRE_OTP) {
                currentAccount = acc;
                JOptionPane.showMessageDialog(this, res.getMessage());
                cardLayout.show(mainPanel, "OTP");
            } else {
                JOptionPane.showMessageDialog(this, res.getMessage(), getStr("msg_login_res"), 
                    res.getStatus() == Response.Status.SUCCESS ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE);
            }
        });

        // Wrapper to center the panel
        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(BG_COLOR);
        wrapper.add(loginPanel);
        mainPanel.add(wrapper, "LOGIN");
    }

    private void initOTPPanel() {
        otpPanel = new JPanel(new GridBagLayout());
        otpPanel.setBackground(PANEL_BG);
        otpPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
                new EmptyBorder(30, 40, 30, 40)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        otpTitleLabel = new JLabel("Verify OTP", SwingConstants.CENTER);
        otpTitleLabel.setFont(TITLE_FONT);
        otpTitleLabel.setForeground(SUCCESS_COLOR);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        otpPanel.add(otpTitleLabel, gbc);

        gbc.gridwidth = 1; gbc.gridy = 1;
        otpEnterLabel = new JLabel("Enter 6-digit OTP:");
        otpEnterLabel.setFont(LABEL_FONT);
        otpPanel.add(otpEnterLabel, gbc);

        JTextField otpField = new JTextField(10);
        otpField.setFont(LABEL_FONT);
        gbc.gridx = 1;
        otpPanel.add(otpField, gbc);

        verifyBtn = new JButton("Verify");
        styleButton(verifyBtn, SUCCESS_COLOR);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 10, 10, 10);
        otpPanel.add(verifyBtn, gbc);

        verifyBtn.addActionListener(e -> {
            String otp = otpField.getText();
            if (otp.length() != 6) {
                JOptionPane.showMessageDialog(this, getStr("msg_otp_invalid"));
                return;
            }

            Request req = new Request(Request.RequestType.VERIFY_OTP);
            req.setPayloadData("otp", otp);

            Response res = networkManager.sendRequest(req);
            if (res.getStatus() == Response.Status.SUCCESS) {
                JOptionPane.showMessageDialog(this, getStr("msg_login_succ"));
                cardLayout.show(mainPanel, "MENU");
            } else {
                JOptionPane.showMessageDialog(this, res.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(BG_COLOR);
        wrapper.add(otpPanel);
        mainPanel.add(wrapper, "OTP");
    }

    private void initMenuPanel() {
        menuPanel = new JPanel(new GridLayout(8, 1, 15, 15));
        menuPanel.setBackground(PANEL_BG);
        menuPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true),
                new EmptyBorder(30, 50, 30, 50)
        ));

        menuTitleLabel = new JLabel("Main Menu", SwingConstants.CENTER);
        menuTitleLabel.setFont(TITLE_FONT);
        menuTitleLabel.setForeground(PRIMARY_COLOR);
        menuPanel.add(menuTitleLabel);

        balanceBtn = new JButton("Check Balance");
        depositBtn = new JButton("Deposit");
        withdrawBtn = new JButton("Withdraw");
        statementBtn = new JButton("Mini Statement");
        changePwdBtn = new JButton("Change Password");
        logoutBtn = new JButton("Logout");

        styleButton(balanceBtn, PRIMARY_COLOR);
        styleButton(depositBtn, PRIMARY_COLOR);
        styleButton(withdrawBtn, PRIMARY_COLOR);
        styleButton(statementBtn, PRIMARY_COLOR);
        styleButton(changePwdBtn, PRIMARY_COLOR);
        styleButton(logoutBtn, DANGER_COLOR);

        menuPanel.add(balanceBtn);
        menuPanel.add(depositBtn);
        menuPanel.add(withdrawBtn);
        menuPanel.add(statementBtn);
        menuPanel.add(changePwdBtn);
        menuPanel.add(logoutBtn);

        balanceBtn.addActionListener(e -> {
            Response res = networkManager.sendRequest(new Request(Request.RequestType.GET_BALANCE));
            if (res.getStatus() == Response.Status.SUCCESS) {
                JOptionPane.showMessageDialog(this, getStr("msg_bal") + " ₹" + res.getPayloadData("balance"));
            } else {
                JOptionPane.showMessageDialog(this, res.getMessage());
            }
        });

        depositBtn.addActionListener(e -> {
            String amount = JOptionPane.showInputDialog(this, getStr("msg_enter_dep"));
            if (amount != null && !amount.trim().isEmpty()) {
                Request req = new Request(Request.RequestType.DEPOSIT);
                req.setPayloadData("amount", amount);
                Response res = networkManager.sendRequest(req);
                JOptionPane.showMessageDialog(this, res.getMessage());
            }
        });

        withdrawBtn.addActionListener(e -> {
            String amount = JOptionPane.showInputDialog(this, getStr("msg_enter_with"));
            if (amount != null && !amount.trim().isEmpty()) {
                Request req = new Request(Request.RequestType.WITHDRAW);
                req.setPayloadData("amount", amount);
                Response res = networkManager.sendRequest(req);
                JOptionPane.showMessageDialog(this, res.getMessage());
            }
        });

        statementBtn.addActionListener(e -> {
            Response res = networkManager.sendRequest(new Request(Request.RequestType.MINI_STATEMENT));
            if (res.getStatus() == Response.Status.SUCCESS) {
                List<Transaction> txs = (List<Transaction>) res.getPayloadData("transactions");
                showMiniStatementDialog(txs);
            } else {
                JOptionPane.showMessageDialog(this, res.getMessage());
            }
        });

        changePwdBtn.addActionListener(e -> {
            JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10));
            JPasswordField oldPassField = new JPasswordField(10);
            JPasswordField newPassField = new JPasswordField(10);
            panel.add(new JLabel(getStr("msg_old_pwd")));
            panel.add(oldPassField);
            panel.add(new JLabel(getStr("msg_new_pwd")));
            panel.add(newPassField);
            
            int option = JOptionPane.showConfirmDialog(this, panel, getStr("change_pwd"), JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (option == JOptionPane.OK_OPTION) {
                String oldPass = new String(oldPassField.getPassword());
                String newPass = new String(newPassField.getPassword());
                
                if (oldPass.isEmpty() || newPass.isEmpty()) {
                    JOptionPane.showMessageDialog(this, getStr("msg_empty_fields"));
                    return;
                }
                
                Request req = new Request(Request.RequestType.CHANGE_PASSWORD);
                req.setPayloadData("oldPassword", oldPass);
                req.setPayloadData("newPassword", newPass);
                Response res = networkManager.sendRequest(req);
                JOptionPane.showMessageDialog(this, res.getMessage());
            }
        });

        logoutBtn.addActionListener(e -> {
            networkManager.sendRequest(new Request(Request.RequestType.LOGOUT));
            currentAccount = null;
            cardLayout.show(mainPanel, "LOGIN");
        });

        JPanel wrapper = new JPanel(new GridBagLayout());
        wrapper.setBackground(BG_COLOR);
        wrapper.add(menuPanel);
        mainPanel.add(wrapper, "MENU");
    }

    private void styleButton(JButton btn, Color bgColor) {
        btn.setFont(BUTTON_FONT);
        btn.setBackground(bgColor);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(new EmptyBorder(10, 20, 10, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setContentAreaFilled(false);
        btn.setOpaque(true);
    }

    private void showMiniStatementDialog(List<Transaction> transactions) {
        JDialog dialog = new JDialog(this, getStr("mini_statement"), true);
        dialog.setSize(450, 350);
        dialog.setLocationRelativeTo(this);

        String[] columnNames = {getStr("col_type"), getStr("col_amt"), getStr("col_date")};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        for (Transaction t : transactions) {
            model.addRow(new Object[]{t.getType(), "₹" + t.getAmount(), t.getTimestamp()});
        }

        JTable table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(25);
        JScrollPane scrollPane = new JScrollPane(table);
        dialog.add(scrollPane);

        dialog.setVisible(true);
    }

    private void updateUIText() {
        loginTitleLabel.setText(getStr("atm_login"));
        loginAccLabel.setText(getStr("acc_num"));
        loginPassLabel.setText(getStr("password"));
        loginBtn.setText(getStr("login"));

        otpTitleLabel.setText(getStr("verify_otp"));
        otpEnterLabel.setText(getStr("enter_otp"));
        verifyBtn.setText(getStr("verify"));

        menuTitleLabel.setText(getStr("main_menu"));
        balanceBtn.setText(getStr("check_balance"));
        depositBtn.setText(getStr("deposit"));
        withdrawBtn.setText(getStr("withdraw"));
        statementBtn.setText(getStr("mini_statement"));
        changePwdBtn.setText(getStr("change_pwd"));
        logoutBtn.setText(getStr("logout"));
    }

    private String getStr(String key) {
        switch (key) {
            case "atm_login":
                if (currentLang == Language.HINDI) return "एटीएम लॉगिन";
                if (currentLang == Language.ODIA) return "ଏଟିଏମ୍ ଲଗଇନ୍";
                return "ATM Login";
            case "acc_num":
                if (currentLang == Language.HINDI) return "खाता संख्या:";
                if (currentLang == Language.ODIA) return "ଆକାଉଣ୍ଟ ନମ୍ବର:";
                return "Account Number:";
            case "password":
                if (currentLang == Language.HINDI) return "पासवर्ड:";
                if (currentLang == Language.ODIA) return "ପାସୱାର୍ଡ:";
                return "Password:";
            case "login":
                if (currentLang == Language.HINDI) return "लॉगिन";
                if (currentLang == Language.ODIA) return "ଲଗଇନ୍";
                return "Login";
            case "verify_otp":
                if (currentLang == Language.HINDI) return "OTP सत्यापित करें";
                if (currentLang == Language.ODIA) return "OTP ଯାଞ୍ଚ କରନ୍ତୁ";
                return "Verify OTP";
            case "enter_otp":
                if (currentLang == Language.HINDI) return "6-अंकीय OTP दर्ज करें:";
                if (currentLang == Language.ODIA) return "6-ଅଙ୍କିତ OTP ଦିଅନ୍ତୁ:";
                return "Enter 6-digit OTP:";
            case "verify":
                if (currentLang == Language.HINDI) return "सत्यापित करें";
                if (currentLang == Language.ODIA) return "ଯାଞ୍ଚ କରନ୍ତୁ";
                return "Verify";
            case "main_menu":
                if (currentLang == Language.HINDI) return "मुख्य मेनू";
                if (currentLang == Language.ODIA) return "ମୁଖ୍ୟ ମେନୁ";
                return "Main Menu";
            case "check_balance":
                if (currentLang == Language.HINDI) return "बैलेंस चेक करें";
                if (currentLang == Language.ODIA) return "ବ୍ୟାଲାନ୍ସ ଯାଞ୍ଚ କରନ୍ତୁ";
                return "Check Balance";
            case "deposit":
                if (currentLang == Language.HINDI) return "जमा करें";
                if (currentLang == Language.ODIA) return "ଜମା କରନ୍ତୁ";
                return "Deposit";
            case "withdraw":
                if (currentLang == Language.HINDI) return "निकासी";
                if (currentLang == Language.ODIA) return "ଉଠାଣ";
                return "Withdraw";
            case "mini_statement":
                if (currentLang == Language.HINDI) return "मिनी स्टेटमेंट";
                if (currentLang == Language.ODIA) return "ମିନି ଷ୍ଟେଟମେଣ୍ଟ";
                return "Mini Statement";
            case "change_pwd":
                if (currentLang == Language.HINDI) return "पासवर्ड बदलें";
                if (currentLang == Language.ODIA) return "ପାସୱାର୍ଡ ବଦଳାନ୍ତୁ";
                return "Change Password";
            case "logout":
                if (currentLang == Language.HINDI) return "लॉग आउट";
                if (currentLang == Language.ODIA) return "ଲଗଆଉଟ୍";
                return "Logout";
            case "msg_empty_fields":
                if (currentLang == Language.HINDI) return "कृपया सभी फ़ील्ड भरें।";
                if (currentLang == Language.ODIA) return "ଦୟାକରି ସମସ୍ତ ଫିଲ୍ଡ୍ ପୂରଣ କରନ୍ତୁ |";
                return "Please enter all fields.";
            case "msg_login_res":
                if (currentLang == Language.HINDI) return "लॉगिन परिणाम";
                if (currentLang == Language.ODIA) return "ଲଗଇନ୍ ଫଳାଫଳ";
                return "Login Result";
            case "msg_otp_invalid":
                if (currentLang == Language.HINDI) return "OTP 6 अंकों का होना चाहिए।";
                if (currentLang == Language.ODIA) return "OTP 6 ଅଙ୍କିତ ହେବା ଉଚିତ୍ |";
                return "OTP must be 6 digits.";
            case "msg_login_succ":
                if (currentLang == Language.HINDI) return "लॉगिन सफल!";
                if (currentLang == Language.ODIA) return "ଲଗଇନ୍ ସଫଳ!";
                return "Login Successful!";
            case "msg_bal":
                if (currentLang == Language.HINDI) return "आपका बैलेंस है:";
                if (currentLang == Language.ODIA) return "ଆପଣଙ୍କର ବ୍ୟାଲାନ୍ସ ହେଉଛି:";
                return "Your Balance is:";
            case "msg_enter_dep":
                if (currentLang == Language.HINDI) return "जमा करने के लिए राशि दर्ज करें:";
                if (currentLang == Language.ODIA) return "ଜମା କରିବାକୁ ଥିବା ରାଶି ଦିଅନ୍ତୁ:";
                return "Enter amount to deposit:";
            case "msg_enter_with":
                if (currentLang == Language.HINDI) return "निकालने के लिए राशि दर्ज करें:";
                if (currentLang == Language.ODIA) return "ଉଠାଇବାକୁ ଥିବା ରାଶି ଦିଅନ୍ତୁ:";
                return "Enter amount to withdraw:";
            case "msg_old_pwd":
                if (currentLang == Language.HINDI) return "पुराना पासवर्ड:";
                if (currentLang == Language.ODIA) return "ପୁରୁଣା ପାସୱାର୍ଡ:";
                return "Old Password:";
            case "msg_new_pwd":
                if (currentLang == Language.HINDI) return "नया पासवर्ड:";
                if (currentLang == Language.ODIA) return "ନୂଆ ପାସୱାର୍ଡ:";
                return "New Password:";
            case "col_type":
                if (currentLang == Language.HINDI) return "प्रकार";
                if (currentLang == Language.ODIA) return "ପ୍ରକାର";
                return "Type";
            case "col_amt":
                if (currentLang == Language.HINDI) return "राशि";
                if (currentLang == Language.ODIA) return "ରାଶି";
                return "Amount";
            case "col_date":
                if (currentLang == Language.HINDI) return "दिनांक";
                if (currentLang == Language.ODIA) return "ତାରିଖ";
                return "Date";
        }
        return key;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ATMClient client = new ATMClient();
            client.setVisible(true);
        });
    }
}
