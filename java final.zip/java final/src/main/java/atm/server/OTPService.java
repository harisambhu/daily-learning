package atm.server;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class OTPService {
    // Stores accountNumber -> OTPData
    private final Map<String, OTPData> otpCache = new HashMap<>();
    private final Random random = new Random();
    private static final long OTP_EXPIRY_MS = 60000; // 60 seconds

    public String generateOTP(String accountNumber) {
        // Generate 6 digit OTP
        String otp = String.format("%06d", random.nextInt(1000000));
        
        OTPData data = new OTPData(otp, System.currentTimeMillis() + OTP_EXPIRY_MS);
        otpCache.put(accountNumber, data);
        
        System.out.println("==================================================");
        System.out.println("OTP for Account " + accountNumber + ": " + otp);
        System.out.println("This OTP is valid for 60 seconds.");
        System.out.println("==================================================");
        
        return otp;
    }

    public boolean verifyOTP(String accountNumber, String inputOtp) {
        OTPData data = otpCache.get(accountNumber);
        if (data == null) {
            return false;
        }

        if (System.currentTimeMillis() > data.expiryTime) {
            otpCache.remove(accountNumber);
            return false; // Expired
        }

        boolean isValid = data.otp.equals(inputOtp);
        if (isValid) {
            otpCache.remove(accountNumber); // OTP used successfully, remove it
        }
        return isValid;
    }

    private static class OTPData {
        String otp;
        long expiryTime;

        OTPData(String otp, long expiryTime) {
            this.otp = otp;
            this.expiryTime = expiryTime;
        }
    }
}
