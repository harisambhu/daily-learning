package atm.server;

import atm.shared.Transaction;
import atm.shared.User;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseManager {
    private static final String URL = "jdbc:mysql://localhost:3307/atm_db";
    private static final String USER = "root";
    private static final String PASSWORD = "root"; // Change if needed

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public boolean validateCredentials(String accountNumber, String passwordHash) {
        String query = "SELECT * FROM users WHERE account_number = ? AND password_hash = ?";
        try (Connection conn = getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, accountNumber);
            stmt.setString(2, passwordHash);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    // Reset failed attempts on success
                    resetFailedAttempts(accountNumber);
                    return true;
                } else {
                    incrementFailedAttempts(accountNumber);
                    return false;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isAccountLocked(String accountNumber) {
        String query = "SELECT is_locked FROM users WHERE account_number = ?";
        try (Connection conn = getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, accountNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getBoolean("is_locked");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void incrementFailedAttempts(String accountNumber) {
        String query = "UPDATE users SET failed_attempts = failed_attempts + 1 WHERE account_number = ?";
        String checkLockQuery = "UPDATE users SET is_locked = TRUE WHERE account_number = ? AND failed_attempts >= 3";
        try (Connection conn = getConnection();
                PreparedStatement stmt = conn.prepareStatement(query);
                PreparedStatement lockStmt = conn.prepareStatement(checkLockQuery)) {
            stmt.setString(1, accountNumber);
            stmt.executeUpdate();

            lockStmt.setString(1, accountNumber);
            lockStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void resetFailedAttempts(String accountNumber) {
        String query = "UPDATE users SET failed_attempts = 0 WHERE account_number = ?";
        try (Connection conn = getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, accountNumber);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public User getUser(String accountNumber) {
        String query = "SELECT * FROM users WHERE account_number = ?";
        try (Connection conn = getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, accountNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new User(
                            rs.getString("account_number"),
                            rs.getBigDecimal("balance"),
                            rs.getString("mobile"),
                            rs.getString("email"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean updateBalance(String accountNumber, BigDecimal amount, String type) {
        String updateQuery = "UPDATE users SET balance = balance + ? WHERE account_number = ?";
        String insertTxQuery = "INSERT INTO transactions (account_number, type, amount) VALUES (?, ?, ?)";

        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false); // Start transaction

            try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
                    PreparedStatement insertTxStmt = conn.prepareStatement(insertTxQuery)) {

                updateStmt.setBigDecimal(1, amount);
                updateStmt.setString(2, accountNumber);
                int rows = updateStmt.executeUpdate();

                if (rows > 0) {
                    insertTxStmt.setString(1, accountNumber);
                    insertTxStmt.setString(2, type);
                    insertTxStmt.setBigDecimal(3, amount.abs());
                    insertTxStmt.executeUpdate();

                    conn.commit();
                    return true;
                } else {
                    conn.rollback();
                    return false;
                }
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Transaction> getMiniStatement(String accountNumber) {
        List<Transaction> transactions = new ArrayList<>();
        String query = "SELECT * FROM transactions WHERE account_number = ? ORDER BY timestamp DESC LIMIT 5";

        try (Connection conn = getConnection();
                PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, accountNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    transactions.add(new Transaction(
                            rs.getInt("id"),
                            rs.getString("account_number"),
                            rs.getString("type"),
                            rs.getBigDecimal("amount"),
                            rs.getTimestamp("timestamp")));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return transactions;
    }

    public boolean updatePassword(String accountNumber, String newPasswordHash) {
        String query = "UPDATE users SET password_hash = ? WHERE account_number = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, newPasswordHash);
            stmt.setString(2, accountNumber);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
