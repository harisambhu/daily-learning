package atm.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ATMServer {
    private static final int PORT = 8080;
    
    public static void main(String[] args) {
        DatabaseManager dbManager = new DatabaseManager();
        OTPService otpService = new OTPService();
        
        System.out.println("Starting ATM Server on port " + PORT + "...");
        
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is listening. Waiting for clients...");
            
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New client connection accepted.");
                
                // Create a new thread for the client
                ClientHandler clientHandler = new ClientHandler(socket, dbManager, otpService);
                Thread thread = new Thread(clientHandler);
                thread.start();
            }
        } catch (IOException e) {
            System.err.println("Could not start server on port " + PORT);
            e.printStackTrace();
        }
    }
}
