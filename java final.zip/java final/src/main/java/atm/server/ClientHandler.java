package atm.server;

import atm.shared.Request;
import atm.shared.Response;
import atm.shared.User;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.net.Socket;

public class ClientHandler implements Runnable {
    private Socket socket;
    private DatabaseManager dbManager;
    private OTPService otpService;
    
    // State of this specific client session
    private String currentAccountNumber = null;
    private boolean isLoggedIn = false;

    public ClientHandler(Socket socket, DatabaseManager dbManager, OTPService otpService) {
        this.socket = socket;
        this.dbManager = dbManager;
        this.otpService = otpService;
    }

    @Override
    public void run() {
        try (
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream())
        ) {
            System.out.println("Client connected: " + socket.getInetAddress());

            while (true) {
                try {
                    Request request = (Request) in.readObject();
                    Response response = handleRequest(request);
                    out.writeObject(response);
                    out.flush();
                } catch (ClassNotFoundException e) {
                    System.err.println("Unknown object received from client");
                }
            }

        } catch (IOException e) {
            System.out.println("Client disconnected: " + socket.getInetAddress());
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private Response handleRequest(Request request) {
        switch (request.getType()) {
            case LOGIN:
                return processLogin(request);
            case VERIFY_OTP:
                return processVerifyOTP(request);
            case GET_BALANCE:
                return processGetBalance();
            case DEPOSIT:
                return processDeposit(request);
            case WITHDRAW:
                return processWithdraw(request);
            case MINI_STATEMENT:
                return processMiniStatement();
            case CHANGE_PASSWORD:
                return processChangePassword(request);
            case LOGOUT:
                return processLogout();
            default:
                return new Response(Response.Status.FAILURE, "Unknown request type");
        }
    }

    private Response processLogin(Request request) {
        String accNum = (String) request.getPayloadData("accountNumber");
        String plainPassword = (String) request.getPayloadData("password");
        
        if (dbManager.isAccountLocked(accNum)) {
            return new Response(Response.Status.LOCKED, "Account is locked due to multiple failed attempts.");
        }

        String hashedPass = SecurityUtils.hashPassword(plainPassword);
        
        if (dbManager.validateCredentials(accNum, hashedPass)) {
            this.currentAccountNumber = accNum;
            // Generate and send OTP
            otpService.generateOTP(accNum);
            return new Response(Response.Status.REQUIRE_OTP, "OTP sent to registered mobile number.");
        } else {
            return new Response(Response.Status.FAILURE, "Invalid Account Number or Password.");
        }
    }

    private Response processVerifyOTP(Request request) {
        if (this.currentAccountNumber == null) {
            return new Response(Response.Status.FAILURE, "Session invalid. Please login again.");
        }
        
        String otp = (String) request.getPayloadData("otp");
        if (otpService.verifyOTP(currentAccountNumber, otp)) {
            this.isLoggedIn = true;
            return new Response(Response.Status.SUCCESS, "Login successful.");
        } else {
            return new Response(Response.Status.FAILURE, "Invalid or Expired OTP.");
        }
    }

    private Response processGetBalance() {
        if (!isLoggedIn) return new Response(Response.Status.FAILURE, "Not logged in.");
        
        User user = dbManager.getUser(currentAccountNumber);
        if (user != null) {
            Response response = new Response(Response.Status.SUCCESS, "Balance retrieved.");
            response.setPayloadData("balance", user.getBalance().toString());
            return response;
        }
        return new Response(Response.Status.FAILURE, "Error retrieving balance.");
    }

    private Response processDeposit(Request request) {
        if (!isLoggedIn) return new Response(Response.Status.FAILURE, "Not logged in.");
        
        try {
            String amountStr = (String) request.getPayloadData("amount");
            BigDecimal amount = new BigDecimal(amountStr);
            
            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                return new Response(Response.Status.FAILURE, "Amount must be positive.");
            }
            
            if (dbManager.updateBalance(currentAccountNumber, amount, "DEPOSIT")) {
                return new Response(Response.Status.SUCCESS, "Deposit successful.");
            } else {
                return new Response(Response.Status.FAILURE, "Deposit failed.");
            }
        } catch (Exception e) {
            return new Response(Response.Status.FAILURE, "Invalid amount format.");
        }
    }

    private Response processWithdraw(Request request) {
        if (!isLoggedIn) return new Response(Response.Status.FAILURE, "Not logged in.");
        
        try {
            String amountStr = (String) request.getPayloadData("amount");
            BigDecimal amount = new BigDecimal(amountStr);
            
            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                return new Response(Response.Status.FAILURE, "Amount must be positive.");
            }
            
            User user = dbManager.getUser(currentAccountNumber);
            if (user == null || user.getBalance().compareTo(amount) < 0) {
                return new Response(Response.Status.FAILURE, "Insufficient balance.");
            }
            
            // Negative amount for updateBalance
            if (dbManager.updateBalance(currentAccountNumber, amount.negate(), "WITHDRAWAL")) {
                return new Response(Response.Status.SUCCESS, "Withdrawal successful.");
            } else {
                return new Response(Response.Status.FAILURE, "Withdrawal failed.");
            }
        } catch (Exception e) {
            return new Response(Response.Status.FAILURE, "Invalid amount format.");
        }
    }

    private Response processMiniStatement() {
        if (!isLoggedIn) return new Response(Response.Status.FAILURE, "Not logged in.");
        
        java.util.List<atm.shared.Transaction> txs = dbManager.getMiniStatement(currentAccountNumber);
        Response response = new Response(Response.Status.SUCCESS, "Mini statement retrieved.");
        response.setPayloadData("transactions", txs);
        return response;
    }

    private Response processLogout() {
        this.isLoggedIn = false;
        this.currentAccountNumber = null;
        return new Response(Response.Status.SUCCESS, "Logged out successfully.");
    }

    private Response processChangePassword(Request request) {
        if (!isLoggedIn) return new Response(Response.Status.FAILURE, "Not logged in.");
        
        String oldPassword = (String) request.getPayloadData("oldPassword");
        String newPassword = (String) request.getPayloadData("newPassword");
        
        String hashedOldPass = SecurityUtils.hashPassword(oldPassword);
        if (!dbManager.validateCredentials(currentAccountNumber, hashedOldPass)) {
            return new Response(Response.Status.FAILURE, "Incorrect old password.");
        }
        
        String hashedNewPass = SecurityUtils.hashPassword(newPassword);
        if (dbManager.updatePassword(currentAccountNumber, hashedNewPass)) {
            return new Response(Response.Status.SUCCESS, "Password changed successfully.");
        } else {
            return new Response(Response.Status.FAILURE, "Failed to change password.");
        }
    }
}
