CREATE DATABASE IF NOT EXISTS atm_db;
USE atm_db;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    account_number VARCHAR(20) UNIQUE NOT NULL,
    password_hash VARCHAR(64) NOT NULL,
    balance DECIMAL(15, 2) DEFAULT 0.00,
    mobile VARCHAR(15) NOT NULL,
    email VARCHAR(100),
    failed_attempts INT DEFAULT 0,
    is_locked BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    account_number VARCHAR(20) NOT NULL,
    type VARCHAR(20) NOT NULL, -- DEPOSIT, WITHDRAWAL
    amount DECIMAL(15, 2) NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_number) REFERENCES users(account_number)
);

-- Insert a default user for testing
-- The password is '1234' (SHA-256 hashed: 03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4)
INSERT INTO users (account_number, password_hash, balance, mobile, email) 
VALUES ('1234567890', '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4', 5000.00, '9876543210', 'test@atm.com')
ON DUPLICATE KEY UPDATE account_number=account_number;
