# Java ATM Simulation Project

This is a complete Java-based ATM Machine simulation project using a Client-Server architecture, AWT/Swing for GUI, and MySQL for database storage. It supports OTP verification, balance inquiries, deposits, withdrawals, and mini-statements.

## Features
- **Client-Server Architecture**: Uses Java Sockets for communication.
- **Database Storage**: Uses MySQL to store user data and transaction history.
- **Security**: Passwords are hashed using SHA-256. Includes an OTP verification step for login.
- **GUI**: Built with Java Swing (CardLayout for seamless navigation).
- **Transactions**: Thread-safe database queries.

## Requirements
- Java Development Kit (JDK) 11 or higher
- Apache Maven (to handle dependencies easily)
- MySQL Server

## Setup Instructions

### 1. Database Setup
1. Open your MySQL client (e.g., MySQL Workbench or Command Line).
2. Run the `src/main/resources/schema.sql` script. This will create the `atm_db` database, tables, and insert a default test user.
3. If your MySQL credentials are not `root` / `root`, you need to update them in `src/main/java/atm/server/DatabaseManager.java`.

**Test User Credentials:**
- Account Number: `1234567890`
- Password: `1234`
- Note: The OTP will be printed on the server console.

### 2. Building the Project
Open a terminal in the project root (where `pom.xml` is located) and run:
```bash
mvn clean compile
```

### 3. Running the Server
You must start the server before the client. Open a terminal in the project root and run:
```bash
mvn exec:java -Dexec.mainClass="atm.server.ATMServer"
```
The server will start listening on port 8080. Leave this terminal open.

### 4. Running the Client
Open a *new* terminal in the project root and run:
```bash
mvn exec:java -Dexec.mainClass="atm.client.ATMClient"
```
The ATM GUI will appear. Enter the test credentials to log in. Check the **Server** terminal for the generated 6-digit OTP to complete the login.

## Project Structure
- `atm.shared.*`: Models (`User`, `Transaction`) and networking objects (`Request`, `Response`) shared by both client and server.
- `atm.server.*`: Multi-threaded server, JDBC database manager, OTP service, and security utilities.
- `atm.client.*`: Swing GUI and socket client for sending requests.
